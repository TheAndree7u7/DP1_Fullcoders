/**
 * @file tiempo.ts
 * @description Utilidades para el manejo del tiempo en la simulación
 */

/**
 * @function formatearTiempoTranscurrido
 * @description Convierte tiempo en formato HH:MM:SS a formato legible como "transcurrieron X días Y horas Z minutos"
 * @param {string} tiempoHMS - Tiempo en formato HH:MM:SS
 * @returns {string} Tiempo formateado de manera legible
 */
export const formatearTiempoTranscurrido = (tiempoHMS: string): string => {
  if (!tiempoHMS || tiempoHMS === "00:00:00") {
    return "No hay tiempo transcurrido";
  }

  const partes = tiempoHMS.split(":");
  const horas = parseInt(partes[0]);
  const minutos = parseInt(partes[1]);
  const segundos = parseInt(partes[2]);

  const totalSegundos = horas * 3600 + minutos * 60 + segundos;
  const dias = Math.floor(totalSegundos / 86400);
  const horasRestantes = Math.floor((totalSegundos % 86400) / 3600);
  const minutosRestantes = Math.floor((totalSegundos % 3600) / 60);

  const resultado = "Transcurrieron ";
  const partes_resultado = [];

  if (dias > 0) {
    partes_resultado.push(`${dias} día${dias > 1 ? 's' : ''}`);
  }
  if (horasRestantes > 0) {
    partes_resultado.push(`${horasRestantes} hora${horasRestantes > 1 ? 's' : ''}`);
  }
  if (minutosRestantes > 0) {
    partes_resultado.push(`${minutosRestantes} minuto${minutosRestantes > 1 ? 's' : ''}`);
  }

  if (partes_resultado.length === 0) {
    return "Transcurrieron menos de un minuto";
  }

  return resultado + partes_resultado.join(' y ');
};

/**
 * @function calcularTimestampSimulacion
 * @description Calcula el timestamp correcto de simulación usando la fecha base con hora 00:00:00 y la horaSimulacion calculada
 * @param {string | null} fechaHoraSimulacion - Fecha y hora base de la simulación del backend
 * @param {string} horaSimulacion - Hora actual de la simulación ya calculada (formato HH:MM:SS)
 * @returns {string} Timestamp ISO de la simulación combinada
 */
export const calcularTimestampSimulacion = (
  fechaHoraSimulacion: string | null,
  horaSimulacion: string
): string => {
  // Si no hay fecha de simulación, devolver timestamp actual como fallback
  if (!fechaHoraSimulacion) {
    console.warn("⚠️ No hay fechaHoraSimulacion disponible, usando timestamp actual como fallback");
    return new Date().toISOString();
  }

  // Extraer solo la fecha (sin hora) de fechaHoraSimulacion de manera más directa
  const fechaOriginal = fechaHoraSimulacion.split('T')[0]; // Obtener solo la parte de fecha "2025-01-01"
  
  // Parsear la horaSimulacion (formato HH:MM:SS)
  const partesHora = horaSimulacion.split(':');
  const horas = parseInt(partesHora[0]);
  const minutos = parseInt(partesHora[1]);
  const segundos = parseInt(partesHora[2]);
  
  // Crear el timestamp completo combinando fecha + hora de simulación
  const fechaSimulacionCompleta = `${fechaOriginal}T${String(horas).padStart(2, '0')}:${String(minutos).padStart(2, '0')}:${String(segundos).padStart(2, '0')}.000Z`;
  
  console.log("📅 TIMESTAMP SIMULACIÓN:", {
    fechaHoraSimulacionOriginal: fechaHoraSimulacion,
    fechaExtraida: fechaOriginal,
    horaSimulacion: horaSimulacion,
    fechaFinal: fechaSimulacionCompleta
  });
  
  return fechaSimulacionCompleta;
}; 